---
title: "Odluka_O_Pocetku_I_Zavrsetku_Nastavne_Godine_2023-2024 (2).docx"
chapter: "13_ADMIN"
chapter_desc: "Administrativna dokumentacija"
source_path: "Odluka_O_Pocetku_I_Zavrsetku_Nastavne_Godine_2023-2024 (2).docx"
file_type: "DOCX"
file_size_kb: "114.2"
converted_at: "2026-06-19 00:31:02"
rag_version: "4.3"
---

Broj: /23

Sarajevo, 31.08.2023. godine

Odluka o početku i završetku nastavne godine, broju radnih dana i trajanju odmora učenika i radnika osnovne škole P.U. Internationale Deutsche Schule Sarajevo – Mešunarodna Njemačka Škola Sarajevo za školsku godinu 2023./2024.

Na temelju članka 48. stavka 4. Zakona o odgoju i obrazovanju u osnovnoj i srednjoj školi (»Narodne novine«, broj 87/08., 86/09., 92/10., 105/10. – ispr., 90/11., 16/12., 86/12., 94/13., 152/14., 7/17., 68/18. i 98/19.), ministar znanosti i obrazovanja donosi

ODLUKU

O POČETKU I ZAVRŠETKU NASTAVNE GODINE, BROJU RADNIH DANA I TRAJANJU ODMORA UČENIKA OSNOVNIH I SREDNJIH ŠKOLA ZA ŠKOLSKU GODINU 2022./2023.

Članak 1.

(1) Ovom Odlukom propisuje se trajanje nastavne godine, odnosno početak i završetak nastave, trajanje polugodišta i trajanje učeničkih odmora te broj radnih dana u osnovnim i srednjim školama za školsku godinu 2022./2023.

(2) Osim zimskog, proljetnog i ljetnog odmora propisanog Zakonom, ovom Odlukom propisuje se jesenski odmor, kao i korištenje zimskog odmora u dva dijela.

(3) Izrazi koji se koriste u ovoj odluci, a koji imaju rodno značenje, bez obzira na to jesu li korišteni u muškome ili ženskome rodu obuhvaćaju na jednak način i muški i ženski rod.

Članak 2.

(1) Nastavna godina počinje 5. rujna 2022. godine, a završava 21. lipnja 2023. godine, odnosno 26. svibnja 2023. godine za učenike završnih razreda srednje škole.

(2) Nastava se ustrojava u dva polugodišta.

(3) Prvo polugodište traje od 5. rujna 2022. godine do 23. prosinca 2022. godine.

(4) Drugo polugodište traje od 9. siječnja 2023. godine do 21. lipnja 2023. godine, a za učenike završnih razreda srednje škole do 26. svibnja 2023. godine.

Članak 3.

(1) Nastava se organizira i izvodi najmanje u 175 nastavnih dana, a za učenike završnih razreda srednje škole najmanje u 160 nastavnih dana.

(2) Ako škola ne ostvari propisani nastavni plan i program/kurikulum, nastavna godina može se produljiti odlukom upravnog tijela županije nadležnog za poslove obrazovanja, odnosno Gradskoga ureda Grada Zagreba nadležnog za poslove obrazovanja (u daljnjem tekstu: nadležno upravno tijelo) uz prethodnu suglasnost ministarstva nadležnog za obrazovanje (u daljnjem tekstu: Ministarstvo) i nakon 21. lipnja 2023. godine, odnosno nakon 26. svibnja 2023. godine za završne razrede srednje škole.

Članak 4.

Jesenski odmor za učenike počinje 31. listopada 2022. godine i traje do 1. studenoga 2022. godine, s tim da nastava počinje 2. studenoga 2022. godine.

Prvi dio zimskoga odmora za učenike počinje 27. prosinca 2022. godine i traje do 5. siječnja 2023. godine, s tim da nastava počinje 9. siječnja 2023. godine.

Drugi dio zimskoga odmora za učenike počinje 20. veljače 2023. godine i završava 24. veljače 2023. godine, s tim da nastava počinje 27. veljače 2023. godine.

Proljetni odmor za učenike počinje 6. travnja 2023. godine i završava 14. travnja 2023. godine, s tim da nastava počinje 17. travnja 2023. godine.

Članak 5.

Ljetni odmor počinje 23. lipnja 2023. godine, osim za učenike koji polažu predmetni, razredni, dopunski ili razlikovni ispit, koji imaju dopunski nastavni rad, završni rad ili ispite državne mature, za učenike u programima čiji se veći dio izvodi u obliku praktične nastave i vježbi, kao i za učenike koji u to vrijeme imaju stručnu praksu, što se utvrđuje godišnjim planom i programom rada škole.

Članak 6.

Iznimno, učenici u strukovnim programima/kurikulumima čiji se veći dio izvodi u obliku praktične nastave i vježbi i/ili koji imaju stručnu praksu mogu imati i drukčiji raspored odmora, s tim da im ukupni odmor tijekom školske godine ne može biti kraći od 45 radnih dana, što se uređuje ugovorom, a sukladno Zakonu o strukovnom obrazovanju (»Narodne novine«, broj 30/09., 24/10., 22/13. i 25/18.).

Članak 7.

Godišnjim planom i programom rada škole utvrđuje se plan i raspored broja nastavnih dana potrebnih za provedbu nastavnoga plana i programa/kurikuluma te broj, plan i raspored ostalih nenastavnih ili nastavnih dana tijekom školske godine potrebnih za druge odgojno-obrazovne programe škole (ispite državne mature, nacionalne ispite, školske priredbe, natjecanja, dan škole, dan župe, dan općine i grada te za izlete, ekskurzije i slično).

Članak 8.

Iznimno, u posebnim okolnostima kada nastavna godina ne može započeti u skladu s ovom Odlukom ili zbog okolnosti koje nije bilo moguće planirati godišnjim planom i programom rada škole, škola može odstupiti od rokova utvrđenih člancima 2., 4. i 5. ove Odluke, o čemu odlučuje ministar nadležan za obrazovanje na zahtjev škole i nadležnoga upravnog tijela.

Članak 9.

Ova Odluka stupa na snagu osmoga dana od dana objave u »Narodnim novinama«.

Klasa: 602-01/22-01/00141
Urbroj: 533-05-22-0001
Zagreb, 2. svibnja 2022.

Ministar
prof. dr. sc. Radovan Fuchs, v. r.